# SIC_PU_Practise
This is for practising and doing the assignment given throughout the course.
